//
//  ZODeviceMonitorShared.h
//  LUMObackDevice
//
//  Created by Denis Bohm on 12/22/11.
//

#import "ZODeviceMonitor.h"

@interface ZODeviceMonitorShared : NSObject<ZODeviceMonitor>

@property (strong) NSMutableArray *devices;
@property (strong) NSString *autoconnectDeviceUUID;

@end
